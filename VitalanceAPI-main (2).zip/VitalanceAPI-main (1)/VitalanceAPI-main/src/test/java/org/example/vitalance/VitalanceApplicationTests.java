package org.example.vitalance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VitalanceApplicationTests {

    @Test
    void contextLoads() {
    }

}

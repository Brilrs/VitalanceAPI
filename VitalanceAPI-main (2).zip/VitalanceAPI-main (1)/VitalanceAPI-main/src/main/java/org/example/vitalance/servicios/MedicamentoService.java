package org.example.vitalance.servicios;

import lombok.RequiredArgsConstructor;
import org.example.vitalance.dtos.MedicamentoDTO;
import org.example.vitalance.entidades.Medicamento;
import org.example.vitalance.interfaces.IMedicamentoService;
import org.example.vitalance.repositorios.MedicamentoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MedicamentoService implements IMedicamentoService {

    private final MedicamentoRepository medicamentoRepository;
    private final ModelMapper modelMapper;

    private MedicamentoDTO toDto(Medicamento e) { return modelMapper.map(e, MedicamentoDTO.class); }
    private Medicamento toEntity(MedicamentoDTO d) { return modelMapper.map(d, Medicamento.class); }

    @Override
    public List<MedicamentoDTO> listar() {
        return medicamentoRepository.findAll().stream().map(this::toDto).toList();
    }

    @Override
    public MedicamentoDTO insertar(MedicamentoDTO dto) {
        Medicamento saved = medicamentoRepository.save(toEntity(dto));
        return toDto(saved);
    }

    @Override
    public MedicamentoDTO editar(MedicamentoDTO dto) {
        // 1) Buscar existente o lanzar excepción
        Medicamento existente = medicamentoRepository.findById(dto.getIdMedicamento())
                .orElseThrow(() -> new RuntimeException("Medicamento no encontrado: " + dto.getIdMedicamento()));

        // 2) Copiar campos del DTO al entity existente (ModelMapper hará el merge)
        modelMapper.map(dto, existente);

        // 3) Guardar y devolver DTO
        Medicamento guardado = medicamentoRepository.save(existente);
        return toDto(guardado);
    }

    @Override
    public MedicamentoDTO buscarPorId(Long id) {
        return medicamentoRepository.findById(id).map(this::toDto)
                .orElseThrow(() -> new RuntimeException("Medicamento no encontrado: " + id));
    }

    @Override
    public void eliminar(Long id) {
        medicamentoRepository.deleteById(id);
    }
}
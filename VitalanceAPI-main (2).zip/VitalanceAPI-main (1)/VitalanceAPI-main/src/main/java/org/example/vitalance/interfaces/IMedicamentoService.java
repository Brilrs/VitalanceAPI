package org.example.vitalance.interfaces;

import org.example.vitalance.dtos.MedicamentoDTO;
import org.example.vitalance.entidades.Comida;
import org.example.vitalance.entidades.Medicamento;

import java.util.List;

public interface IMedicamentoService {
    List<MedicamentoDTO> listar();
    MedicamentoDTO insertar(MedicamentoDTO medicamento);
    public MedicamentoDTO editar(MedicamentoDTO medicamento);
    MedicamentoDTO buscarPorId(Long id);
    public void eliminar(Long id);

}

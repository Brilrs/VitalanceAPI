package org.example.vitalance.controllers;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.example.vitalance.dtos.MedicamentoDTO;
import org.example.vitalance.entidades.Medicamento;
import org.example.vitalance.interfaces.IMedicamentoService;
import org.example.vitalance.servicios.MedicamentoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/apiMedicamento")
public class MedicamentoController {

    private final IMedicamentoService medicamentoService;

    @GetMapping("/listar")
    public List<MedicamentoDTO> listar(){
        log.info("Listando medicamentos");
        return medicamentoService.listar();
    }

    @PostMapping("/insertar")
    public ResponseEntity<MedicamentoDTO> insertar(@Valid @RequestBody MedicamentoDTO medicamentoDTO){
        log.info("Insertando medicamento: {}", medicamentoDTO.getIdMedicamento());
        return  ResponseEntity.ok().body(medicamentoService.insertar(medicamentoDTO));
    }

    @PutMapping("/editar")
    public ResponseEntity<MedicamentoDTO>editar(@RequestBody MedicamentoDTO medicamentoDTO){
        return ResponseEntity.ok().body(medicamentoService.editar(medicamentoDTO));
    }

    @GetMapping("/ver/{id}")
    public ResponseEntity<MedicamentoDTO>ver(@PathVariable Long id){
        return ResponseEntity.ok(medicamentoService.buscarPorId(id));
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id){ medicamentoService.eliminar(id);}


}

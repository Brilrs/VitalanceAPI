package org.example.vitalance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VitalanceApplication {

    public static void main(String[] args) {
        SpringApplication.run(VitalanceApplication.class, args);
    }

}
